import sqlite3


class Movie:
    def __init__(self):
        self.base = sqlite3.connect("./backend/dataBases/Movie.db")
        self.cur = self.base.cursor()

        self.cur.execute(
            """CREATE TABLE IF NOT EXISTS Movies (
               id INTEGER PRIMARY KEY AUTOINCREMENT,
               movieName TEXT,
               studioName TEXT,
               genre TEXT,
               creationYear INT,
               duration INT,
               author TEXT,
               review LONGTEXT,
               score INTEGER
               );
               """)


    def Add(self, movieName: str, studioName: str, genre: str, creatingYear: int, duration: int, author: str, review: str, score: int):
        self.cur.execute("""INSERT INTO Movies (id, movieName, studioName, genre, creationYear, duration, author, review, score) VALUES(NULL, ?, ?, ?, ?, ?, ?, ?, ?);""",(movieName, studioName, genre, creatingYear, duration, author, review, score, ))
        self.base.commit()

        return self.cur.lastrowid


    def Display(self, name: str = "Any", studioName: str = "Any", periodStart: int = 1900, periodEnd: int = 2023, genre: str = "Any", durationMin: int = 1, durationMax: int = 99999999):
        movieList = self.cur.execute(
                """SELECT id, movieName, author FROM Movies WHERE
                   creationYear BETWEEN {0} AND {1} AND duration BETWEEN {2} AND {3}""".format(periodStart, periodEnd, durationMin, durationMax) +
               (""" AND (movieName = '{}' OR author = '{}')""".format(name, name), """""")[name == "Any"] +
               (""" AND studioName = '{}'""".format(studioName), """""")[studioName == "Any"] +
               (""" AND genre = '{}'""".format(genre), """""")[genre == "Any"]).fetchall()

        return movieList
    

    def ViewMovie(self, movieId: int):
        data = self.cur.execute("""SELECT * FROM Movies WHERE id = {}""".format(movieId)).fetchone()

        return data
    
    def ViewAll(self):
        data = self.cur.execute("""SELECT * FROM Movies""").fetchall()

        return data
    
    def IsDataBaseVoid(self):
        return self.cur.execute("""SELECT * FROM Movies""").fetchall() == []
            
import sqlite3

class Actor:
    def __init__(self):
        self.base = sqlite3.connect("./backend/dataBases/Actors.db")
        self.cur = self.base.cursor()


    def Add(self, movieName: str, actors_list: list):
        self.cur.execute(
            """CREATE TABLE IF NOT EXISTS '{}' (
               actor TEXT
               );
            """.format(movieName))
  
        for actor in actors_list:
            self.cur.execute("""INSERT INTO '{}' (actor) VALUES(?);""".format(movieName),(actor,))
            self.base.commit()      


    def View(self, movieName: str):
        return self.cur.execute("""SELECT * FROM '{}'""".format(movieName)).fetchall()
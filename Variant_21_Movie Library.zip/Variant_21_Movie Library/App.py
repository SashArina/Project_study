from PyQt6 import QtWidgets
from UI.mainWindow import MainWindow
from backend.classes.movieDataBaseClass import Movie
import sys

if __name__ == "__main__":
    if(not(Movie().IsDataBaseVoid())):
        app = QtWidgets.QApplication(sys.argv)
        window = MainWindow()
        window.show()
        sys.exit(app.exec())
from PyQt6 import QtWidgets, QtCore
from datetime import datetime
import sys
import json

from backend.classes.movieDataBaseClass import Movie
from backend.classes.actorsDataBaseClass import Actor

def on_btn_clicked(params: list):
    movies = Movie()
    actors = Actor()

    for el in params:
        if(el == ""):
            print("Some of the inputs is void")
            return
        
    movieId = movies.Add(params[0], params[1], params[2], params[3], params[4], params[5], params[6], params[7])
    actors.Add(movieId, params[8].split(','))

    print("Completed")


if __name__ == "__main__":
    my_signal = QtCore.pyqtSignal(list)

    app = QtWidgets.QApplication(sys.argv)
    wnd = QtWidgets.QMainWindow()
    wnd.setWindowTitle("DataBassesCreating")

    layout = QtWidgets.QVBoxLayout()

    widget = QtWidgets.QWidget()

    widget.setLayout(layout)

    name = QtWidgets.QLineEdit()
    name.setPlaceholderText("MovieName")

    studio = QtWidgets.QComboBox()
    studio.setPlaceholderText("StudioName")
    studio.addItems(json.load(open("UI\jsons\studios.json")))

    genre = QtWidgets.QComboBox()
    genre.setPlaceholderText("Genre")
    genre.addItems(json.load(open("UI\jsons\genre.json")))

    creatingYear = QtWidgets.QSpinBox()
    creatingYear.setMinimum(1900)
    creatingYear.setMaximum(datetime.now().year)

    duration = QtWidgets.QSpinBox()
    duration.setMinimum(1)
    duration.setMaximum(99999998)

    author = QtWidgets.QLineEdit()
    author.setPlaceholderText("Author")

    review = QtWidgets.QTextEdit()
    review.setPlaceholderText("Enter the review")

    score = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
    score.setRange(1, 10)

    actor_list = QtWidgets.QTextEdit()
    actor_list.setPlaceholderText("Enter the actors")

    button = QtWidgets.QPushButton()
    button.setText("Apply")

    button.clicked.connect(lambda: on_btn_clicked(([name.text(), studio.currentText(), genre.currentText(), creatingYear.value(), duration.value(), author.text(), review.toPlainText(), score.value(), actor_list.toPlainText()])))

    layout.addWidget(name)
    layout.addWidget(studio)
    layout.addWidget(genre)
    layout.addWidget(creatingYear)
    layout.addWidget(duration)
    layout.addWidget(author)
    layout.addWidget(review)
    layout.addWidget(score)
    layout.addWidget(actor_list)
    layout.addWidget(button)

    wnd.setCentralWidget(widget)

    wnd.show()
    sys.exit(app.exec())


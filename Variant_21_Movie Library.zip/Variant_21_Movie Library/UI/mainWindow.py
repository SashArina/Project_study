from PyQt6 import QtCore, QtGui, QtWidgets
from datetime import datetime

from .components.plate import MoviePlate
from .components.filter import Filter
from .components.discription import PlateDiscription
from .components.statistic import Statistic

from backend.classes.movieDataBaseClass import Movie
from backend.classes.actorsDataBaseClass import Actor


class MainWindow(QtWidgets.QMainWindow):
    movies = Movie()
    actors = Actor()

    name: str = "Any"
    studioName: str = "Any"
    periodStart: int = 1900
    periodEnd: int = datetime.now().year
    genre: str = "Any"
    durationMin: int = 1
    durationMax: int = 99999999


    def __init__(self):
        super().__init__()

        self.setupUi(self)


    def setupUi(self, MainWindow):

#_____________________________________________StyleSheets__________________________________________________
        navbarButtonStyleSheet ="""
                                    QPushButton {
                                        border-radius: 10px;
                                        color: rgba(217, 217, 217, 1);
                                        background-color: rgba(116, 124, 166, 1);
                                    }
                                    QPushButton:hover:hover{
                                        background-color: rgba(58, 64, 96, 1);
                                    }
                                """
        closeButtonStyleSheet = """
                                    QPushButton {\n
                                        border-top-left-radius: 10px;
                                        border-top-right-radius: 20px;
                                        border-bottom-left-radius: 10px;
                                        border-bottom-right-radius: 20px;
                                        color: rgba(217, 217, 217, 1);
                                        background-color: rgba(30, 30, 30, 1);
                                    }
                                    QPushButton:hover:hover{
                                        background-color: rgba(111, 14, 14, 1);
                                    }
                                """
        helpButtonStyleSheet =  """
                                    QPushButton {\n
                                        border-top-left-radius: 20px;
                                        border-top-right-radius: 10px;
                                        border-bottom-left-radius: 20px;
                                        border-bottom-right-radius: 10px;
                                        color: rgba(217, 217, 217, 1);
                                        background-color: rgba(30, 30, 30, 1);
                                    }
                                    QPushButton:hover:hover{
                                        background-color: rgba(111, 14, 14, 1);
                                    }
                                """
        inputStyleSheet =       """
                                    QLineEdit {
                                        border-radius: 10px;
                                        color: rgba(0, 0, 0, 0.8);
                                        background-color: rgba(217, 217, 217, 1);
                                        padding: 5px;
                                    }
                                    QLineEdit:focus:focus{
                                        background-color: rgba(255, 255, 255, 1);
                                        color: rgba(50, 50, 50, 1);
                                    }
                                """
        mainWindowStyleSheet =  """
                                    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2: 1, y2:1, stop:0 rgba(17, 20, 73, 1), stop:1 rgba(5, 6, 32, 1));
                                    border-radius: 20px;
                                """
        navbarStyleSheet =      """
                                    background-color: rgba(3, 4, 32, 1);
                                    border-radius: 20px;
                                """
        enterButtonStyleSheet = """
                                   QPushButton {
                                       border-top-right-radius: 10px;
                                       border-bottom-right-radius: 10px;
                                       color: rgba(217, 217, 217, 1);
                                       background-color: rgba(116, 124, 166, 1);
                                    }
                                    QPushButton:hover:hover{
                                        background-color: rgba(58, 64, 96, 1);
                                    }
                                """
        contentFrameStyleSheet ="""
                                    background-color: rgba(0, 0, 0, 0);
                                """
#__________________________________________________________________________________________________________

        self.setWindowIcon(QtGui.QIcon("UI/images/app_icon.png"))
        
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1010, 710)
        MainWindow.setBaseSize(QtCore.QSize(0, 0))
        MainWindow.setWindowTitle("Movies Library")

        self.setWindowFlags(QtCore.Qt.WindowType.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground)

        self.font = QtGui.QFont()
        self.font.setFamily("Inter")

        self.central_widget = QtWidgets.QWidget(MainWindow)
        self.central_widget.setObjectName("central_widget")

        self.mainWindow_frame = QtWidgets.QFrame(self.central_widget)
        self.mainWindow_frame.setGeometry(QtCore.QRect(5, 5, 1000, 700))
        self.mainWindow_frame.setStyleSheet(mainWindowStyleSheet)
        self.mainWindow_frame.setObjectName("mainWindow_frame")

        self.navbar_frame = QtWidgets.QFrame(self.mainWindow_frame)
        self.navbar_frame.setGeometry(QtCore.QRect(0, 0, 1000, 80))
        self.navbar_frame.setStyleSheet(navbarStyleSheet)
        self.navbar_frame.setObjectName("navbar_frame")

        self.exit_button = QtWidgets.QPushButton(self.navbar_frame)
        self.exit_button.setGeometry(QtCore.QRect(970, 0, 30, 80))
        self.exit_button.setFont(self.font)
        self.exit_button.setText("Q\nU\nI\nT")
        self.exit_button.setStyleSheet(closeButtonStyleSheet)
        self.exit_button.setObjectName("button_exit")

        self.help_button = QtWidgets.QPushButton(self.navbar_frame)
        self.help_button.setGeometry(QtCore.QRect(0, 0, 30, 80))
        self.help_button.setFont(self.font)
        self.help_button.setText("H\nE\nL\nP")
        self.help_button.setStyleSheet(helpButtonStyleSheet)
        self.help_button.setObjectName("help_button")

        self.filter_button = QtWidgets.QPushButton(self.navbar_frame)
        self.filter_button.setGeometry(QtCore.QRect(800, 25, 100, 30))
        self.filter_button.setText("Filter")
        self.filter_button.setStyleSheet(navbarButtonStyleSheet)
        self.filter_button.setObjectName("filter_button")

        self.statisics_button = QtWidgets.QPushButton(self.navbar_frame)
        self.statisics_button.setGeometry(QtCore.QRect(100, 25, 100, 30))
        self.statisics_button.setText("Statisics")
        self.statisics_button.setStyleSheet(navbarButtonStyleSheet)
        self.statisics_button.setObjectName("statisics_button")

        self.input_lineEdit = QtWidgets.QLineEdit(self.navbar_frame)
        self.input_lineEdit.setGeometry(QtCore.QRect(250, 25, 500, 30))
        self.input_lineEdit.setFont(self.font)
        self.input_lineEdit.setPlaceholderText("Enter Movie or Author")
        self.input_lineEdit.setStyleSheet(inputStyleSheet)
        self.input_lineEdit.setObjectName("input_lineEdit")

        self.enter_button = QtWidgets.QPushButton(self.input_lineEdit)
        self.enter_button.setGeometry(QtCore.QRect(470, 0, 30, 30))
        self.enter_button.setShortcut("Return")
        self.enter_button.setStyleSheet(enterButtonStyleSheet)
        self.enter_button.setObjectName("enter_button")

        self.content_frame = QtWidgets.QFrame(self.mainWindow_frame)
        self.content_frame.setGeometry(QtCore.QRect(0, 80, 1000, 620))
        self.content_frame.setStyleSheet(contentFrameStyleSheet)

        self.content_layout = QtWidgets.QGridLayout(self.content_frame)
        self.content_layout.setAlignment(QtCore.Qt.AlignmentFlag.AlignTop | QtCore.Qt.AlignmentFlag.AlignLeft)
        self.content_layout.setVerticalSpacing(30)
        self.content_layout.setHorizontalSpacing(40)
        self.content_layout.setContentsMargins(0, 20, 0, 30)

        self.content_widget = QtWidgets.QWidget()
        self.content_widget.setLayout(self.content_layout)

        self.content_scrollArea = QtWidgets.QScrollArea(self.content_frame)
        self.content_scrollArea.setGeometry(QtCore.QRect(70, 0, 865, 620))
        #Hiden scrollbar
        self.content_scrollArea.verticalScrollBar().hide()
        #Custom scrollbar
        #CtrlC CtrlV StyleSheet from end of file

        self.content_scrollArea.setVerticalScrollBarPolicy(
            QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOn
        )
        self.content_scrollArea.setHorizontalScrollBarPolicy(
            QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self.content_scrollArea.setWidgetResizable(True)
        self.content_scrollArea.setWidget(self.content_widget)  

        self.filter_widget = Filter(self.mainWindow_frame)
        self.statictic_widget = Statistic(self.mainWindow_frame)
        self.statictic_widget.SetData(self.movies.ViewAll())
        self.disciption_widget = PlateDiscription(self.mainWindow_frame)

        self.UpdateContent()

        self.exit_button.clicked.connect(self.CloseWindow)
        self.help_button.clicked.connect(self.ViewHelp)
        self.statisics_button.clicked.connect(self.ViewStatisitcs)
        self.filter_button.clicked.connect(self.ViewFilters)
        self.enter_button.clicked.connect(self.InputChanged)

        self.filter_widget.filter_signal.connect(self.on_filter_chenged)

        MainWindow.setCentralWidget(self.central_widget)

        QtCore.QMetaObject.connectSlotsByName(MainWindow)


    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.MouseButton.LeftButton:
            self.dragPosition = (
                QtCore.QPointF.toPoint(event.position())
                - self.frameGeometry().topLeft()
            )
            event.accept()


    def mouseMoveEvent(self, event):
        if event.buttons() == QtCore.Qt.MouseButton.LeftButton:
            self.move(QtCore.QPointF.toPoint(event.position()) - self.dragPosition)
            event.accept()


    def CloseWindow(self):
        self.close()
        if hasattr(self, "find_tr_wnd"):
            self.find_tr_wnd.close()
        if hasattr(self, "find_dk_wnd"):
            self.find_dk_wnd.close()
        if hasattr(self, "add_tr_wnd"):
            self.add_tr_wnd.close()
        if hasattr(self, "view_all_wnd"):
            self.view_all_wnd.close()


    def ViewHelp(self):
        msg = QtWidgets.QMessageBox()
        msg.setIcon(QtWidgets.QMessageBox.Icon.Question)
        msg.setWindowIcon(QtGui.QIcon("Images\headphones.png"))
        msg.setText("Description of the application features:")
        msg.setInformativeText(
            """
            WELCOME!
            This application is an assistant for real movie lovers.
            In the search, you can write the name of the movie or its director.
            Using the "filter" button, you can sort movies from the library.
            In the statistics section, you can view statistics in 4 categories,
            as well as display a diagram about the genres of films.
            And find out the shortest and longest movie. 
            Enjoy your use!
            """
        )
        msg.setWindowTitle("Help")
        msg.setStandardButtons(QtWidgets.QMessageBox.StandardButton.Cancel)
        msg.setStyleSheet("QPushButton{ width:440px;}")
        msg.exec()


    def UpdateContent(self):
        for i in reversed(range(self.content_layout.count())): 
            self.content_layout.itemAt(i).widget().setParent(None)

        movieList = self.movies.Display(self.name, self.studioName, self.periodStart, self.periodEnd, self.genre, self.durationMin, self.durationMax)

        if(movieList == []):
            msg = QtWidgets.QMessageBox()
            msg.setIcon(QtWidgets.QMessageBox.Icon.Information)
            msg.setText("Nothing was found")
            msg.setWindowTitle("Alert")
            msg.setStandardButtons(QtWidgets.QMessageBox.StandardButton.Ok)
            msg.setStyleSheet("QPushButton{ width:200px;}")
            msg.exec()

            self.name = "Any"
            self.studioName = "Any"
            self.periodStart = 1900
            self.periodEnd = datetime.now().year
            self.genre = "Any"
            self.durationMin = 1
            self.durationMax = 99999999

            self.UpdateContent()
        else:
            for movieDB_index, movie in enumerate(movieList):
                plate = MoviePlate(movie[0], movie[1], movie[2])
                plate.plateClicked_signal.connect(self.on_plate_clicked)
                self.content_layout.addWidget(plate, movieDB_index // 4, movieDB_index % 4, QtCore.Qt.AlignmentFlag.AlignCenter)


    def ViewFilters(self):        
        self.filter_widget.SetVisible()


    def ViewStatisitcs(self):
        self.statictic_widget.SetVisible()


    def InputChanged(self):
        self.name = self.input_lineEdit.text()
        if(self.name == ""):
            self.name = "Any"

        self.UpdateContent()


    @QtCore.pyqtSlot(list)
    def on_filter_chenged(self, value):
        self.studioName = value[1]
        self.periodStart = value[4]
        self.periodEnd = value[5]
        self.genre = value[0]
        self.durationMin = value[2]
        self.durationMax = value[3]

        self.UpdateContent()


    @QtCore.pyqtSlot(int)
    def on_plate_clicked(self, value):
        movieData = self.movies.ViewMovie(value)
        actorsList = self.actors.View(value)
        self.disciption_widget.SetData(movieData, actorsList)
        self.disciption_widget.SetVisible()




#Custom scrollbar

# self.content_scrollArea.verticalScrollBar().setStyleSheet(
#     """
#     QScrollBar::handle:vertical
#     {
#         background-color: rgba(30, 30, 30, 1);
#         min-height: 5px;
#         border-radius: 8px;
#     }
#     QScrollBar::handle:vertical:active
#     {
#         background-color: rgba(20, 20, 20, 1);
#         min-height: 5px;
#         border-radius: 8px;
#     }
#     QScrollBar::sub-line:vertical
#     {
#         height: 0px;
#         width: 0px;
#         subcontrol-position: top;
#         subcontrol-origin: margin;
#     }
#     QScrollBar::add-line:vertical
#     {
#         height: 0px;
#         width: 0px;
#         subcontrol-position: bottom;
#         subcontrol-origin: margin;
#     }
#     QScrollBar::sub-line:vertical:hover,QScrollBar::sub-line:vertical:on
#     {
#         height: 0px;
#         width: 0px;
#         subcontrol-position: top;
#         subcontrol-origin: margin;
#     }
#     QScrollBar::add-line:vertical:hover, QScrollBar::add-line:vertical:on
#     {
#         height: 0px;
#         width: 0px;
#         subcontrol-position: bottom;
#         subcontrol-origin: margin;
#     }
#     QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical
#     {
#         background: none;
#     }
#     QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical
#     {
#         background: none;
#     }
#     """
# )
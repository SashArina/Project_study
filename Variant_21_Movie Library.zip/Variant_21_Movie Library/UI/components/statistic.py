from PyQt6 import QtCore, QtGui, QtWidgets
import matplotlib.pyplot as plot


class Statistic(QtWidgets.QWidget):
   visible = False

   studiosDublicates = []
   genersDublicates = []
   yearsDublicates = []
   authorsDublicates = []


   def __init__(self, parent = None):
      super().__init__(parent)

#_____________________________________________StyleSheets__________________________________________________
      statisticFrameStyleSheet = """
                                    background-color: rgba(255, 3, 62, 1);
                                    border-radius: 10px;
                                 """ 
      closeButtonStyleSheet =    """
                                    QPushButton {\n
                                       border-top-left-radius: 5px;
                                       border-top-right-radius: 10px;
                                       border-bottom-left-radius: 10px;
                                       border-bottom-right-radius: 5px;
                                       color: rgba(217, 217, 217, 1);
                                       background-color: rgba(30, 30, 30, 1);
                                    }
                                    QPushButton:hover:hover{
                                       background-color: rgba(111, 14, 14, 1);
                                    }
                                 """
      tableStyleSheet =          """
                                    background-color: rgba(217, 217, 217, 1);
                                    border-radius: 0px;
                                 """
      durationLabelStyleSheet =  """
                                    padding-left: 5px;
                                    padding-top: 1px;
                                    color: rgba(5, 6, 32, 0.5);
                                    background-color: rgba(255, 255, 255, 0.1);
                                 """
      plotButtonStyleSheet =     """
                                    QPushButton {\n
                                       border-radius: 10px;
                                       color: rgba(30, 30, 30, 1);
                                       background-color: rgba(217, 217, 217, 1);
                                    }
                                    QPushButton:hover:hover{
                                       background-color: rgba(170, 170, 170, 1);
                                    }
                                 """
#__________________________________________________________________________________________________________

      self.font = QtGui.QFont()
      self.font.setFamily("Inter")

      self.statictic_frame = QtWidgets.QFrame(parent)
      self.statictic_frame.setGeometry(QtCore.QRect(50, 50, 900, 550))
      self.statictic_frame.setStyleSheet(statisticFrameStyleSheet)
      self.statictic_frame.setObjectName("statictic_frame")
      self.statictic_frame.setVisible(self.visible)

      shadow = QtWidgets.QGraphicsDropShadowEffect(
            self,
            blurRadius=100.0,
            color=QtGui.QColor(0, 0, 0),
            offset=QtCore.QPointF(0.0, 0.0),
        )
      self.statictic_frame.setGraphicsEffect(shadow)

      self.close_button = QtWidgets.QPushButton(self.statictic_frame)
      self.close_button.setGeometry(QtCore.QRect(870, 0, 30, 30))
      self.close_button.setFont(self.font)
      self.close_button.setText("X")
      self.close_button.setStyleSheet(closeButtonStyleSheet)
      self.close_button.setObjectName("close_button")
      self.close_button.clicked.connect(self.SetVisible)

      self.studiosStatisitic_table = QtWidgets.QTableWidget(self.statictic_frame)
      self.studiosStatisitic_table.setGeometry(30, 30, 410, 200)
      self.studiosStatisitic_table.setColumnCount(2)
      self.studiosStatisitic_table.setHorizontalHeaderLabels(["Studio", "Movie count"])
      self.studiosStatisitic_table.setColumnWidth(0, 276)
      self.studiosStatisitic_table.setColumnWidth(1, 95)
      self.studiosStatisitic_table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
      self.studiosStatisitic_table.setStyleSheet(tableStyleSheet)

      self.genreStatisitic_table = QtWidgets.QTableWidget(self.statictic_frame)
      self.genreStatisitic_table.setGeometry(460, 30, 410, 200)
      self.genreStatisitic_table.setColumnCount(3)
      self.genreStatisitic_table.setHorizontalHeaderLabels(["Genre", "Movie count", "Averege duration"])
      self.genreStatisitic_table.setColumnWidth(0, 171)
      self.genreStatisitic_table.setColumnWidth(1, 100)
      self.genreStatisitic_table.setColumnWidth(2, 100)
      self.genreStatisitic_table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
      self.genreStatisitic_table.setStyleSheet(tableStyleSheet)

      self.releaseYearStatisitic_table = QtWidgets.QTableWidget(self.statictic_frame)
      self.releaseYearStatisitic_table.setGeometry(30, 250, 410, 200)
      self.releaseYearStatisitic_table.setColumnCount(2)
      self.releaseYearStatisitic_table.setHorizontalHeaderLabels(["Year of the release", "Movie Count"])
      self.releaseYearStatisitic_table.setColumnWidth(0, 276)
      self.releaseYearStatisitic_table.setColumnWidth(1, 95)
      self.releaseYearStatisitic_table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
      self.releaseYearStatisitic_table.setStyleSheet(tableStyleSheet)

      self.authorStatisitic_table = QtWidgets.QTableWidget(self.statictic_frame)
      self.authorStatisitic_table.setGeometry(460, 250, 410, 200)
      self.authorStatisitic_table.setColumnCount(2)
      self.authorStatisitic_table.setHorizontalHeaderLabels(["Author", "Movie Count"])
      self.authorStatisitic_table.setColumnWidth(0, 276)
      self.authorStatisitic_table.setColumnWidth(1, 95)
      self.authorStatisitic_table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
      self.authorStatisitic_table.setStyleSheet(tableStyleSheet)

      self.movieMinDuration_label = QtWidgets.QLabel(self.statictic_frame)
      self.movieMinDuration_label.setGeometry(QtCore.QRect(30, 470, 530, 20))
      self.font.setPointSize(10)
      self.movieMinDuration_label.setFont(self.font)
      self.movieMinDuration_label.setStyleSheet(durationLabelStyleSheet)
      self.movieMinDuration_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)

      self.movieMaxDuration_label = QtWidgets.QLabel(self.statictic_frame)
      self.movieMaxDuration_label.setGeometry(QtCore.QRect(30, 500, 530, 20))
      self.font.setPointSize(10)
      self.movieMaxDuration_label.setFont(self.font)
      self.movieMaxDuration_label.setStyleSheet(durationLabelStyleSheet)
      self.movieMaxDuration_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)

      self.plot_button = QtWidgets.QPushButton(self.statictic_frame)
      self.plot_button.setGeometry(580, 470, 290, 50)
      self.plot_button.setStyleSheet(plotButtonStyleSheet)
      self.plot_button.setFont(self.font)
      self.plot_button.setText("Create Plot")
      self.plot_button.clicked.connect(self.MakePlot)


   def SetVisible(self):
      self.visible = not (self.visible)
      self.statictic_frame.setVisible(self.visible)


   def SetData(self, data: tuple):
      studios = []
      geners = []
      years = []
      authors = []

      for movieData in data:
         studios.append(movieData[2])
         geners.append(movieData[3])
         years.append(movieData[4])
         authors.append(movieData[6])

      self.studiosDublicates = self.CountDublicate(studios)
      self.genersDublicates = self.CountDublicate(geners)
      self.yearsDublicates = self.CountDublicate(years)
      self.authorsDublicates = self.CountDublicate(authors)
      
      for i in range(len(self.studiosDublicates)):
         self.studiosStatisitic_table.insertRow(i)
         self.studiosStatisitic_table.setItem(i, 0, QtWidgets.QTableWidgetItem(self.studiosDublicates[i][0]))
         self.studiosStatisitic_table.setItem(i, 1, QtWidgets.QTableWidgetItem(self.studiosDublicates[i][1]))

      for i in range(len(self.genersDublicates)):
         self.genreStatisitic_table.insertRow(i)
         self.genreStatisitic_table.setItem(i, 0, QtWidgets.QTableWidgetItem(self.genersDublicates[i][0]))
         self.genreStatisitic_table.setItem(i, 1, QtWidgets.QTableWidgetItem(self.genersDublicates[i][1]))
         self.genreStatisitic_table.setItem(i, 2, QtWidgets.QTableWidgetItem(self.AvarageDuration(data, self.genersDublicates[i][0], self.genersDublicates[i][1])))

      for i in range(len(self.yearsDublicates)):
         self.releaseYearStatisitic_table.insertRow(i)
         self.releaseYearStatisitic_table.setItem(i, 0, QtWidgets.QTableWidgetItem(self.yearsDublicates[i][0]))
         self.releaseYearStatisitic_table.setItem(i, 1, QtWidgets.QTableWidgetItem(self.yearsDublicates[i][1]))

      for i in range(len(self.authorsDublicates)):
         self.authorStatisitic_table.insertRow(i)
         self.authorStatisitic_table.setItem(i, 0, QtWidgets.QTableWidgetItem(self.authorsDublicates[i][0]))
         self.authorStatisitic_table.setItem(i, 1, QtWidgets.QTableWidgetItem(self.authorsDublicates[i][1]))
      
      self.movieMinDuration_label.setText("Movie with minimum duration: " + self.MinMaxDuration(data)[0])
      self.movieMaxDuration_label.setText("Movie with maximum duration: " + self.MinMaxDuration(data)[1])



   def AvarageDuration(self, data: tuple, genre: str, count: str):
      duration = 0;
      for item in data:
         if item[3] == genre:
            duration += item[5]

      return str(duration // int(count))


   def MinMaxDuration(self, data: tuple):
      minDuration = 100000000
      maxDuration = 0

      for item in data:
         if item[5] < minDuration:
            minDuration = item[5]
            minDurationName = item[1]
         if item[5] > maxDuration:
            maxDuration = item[5]
            maxDurationName = item[1]

      return [minDurationName, maxDurationName]



   def CountDublicate(self, data: list):
      unDublicatesData = list(set(data))
      dublicates = [[str(item), str(data.count(item))] for item in unDublicatesData]
      
      return dublicates
   
   def MakePlot(self):
      plot.rcParams['toolbar'] = 'None'
      genre_plot = plot.figure(figsize=(6, 4))
      diagram = genre_plot.add_subplot()

      x = [item[0] for item in self.genersDublicates]
      y = [int(item[1]) for item in self.genersDublicates]
      diagram.bar(x, y)
      
      genre_plot.show()
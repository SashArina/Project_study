from PyQt6 import QtCore, QtWidgets, QtGui

class MoviePlate(QtWidgets.QWidget):
   id: int
   plateClicked_signal = QtCore.pyqtSignal(int)


   def __init__(self, movie_id: int, movieName: str = "Name", authorName: str = "Name", parent = None):
      super().__init__(parent)

#_____________________________________________StyleSheets__________________________________________________
      plateStyleSheet =       """
                                 QWidget{
                                    background-color: rgba(217, 217, 217, 1);
                                    border-radius: 10px;
                                 }
                                 QWidget:hover{
                                    background-color: rgba(190, 190, 190, 1);
                                 }
                              """ 
      plateNameStyleSheet =   """
                                 background-color: rgba(116, 124, 166, 1);
                                 border-top-left-radius: 0px;
                                 border-top-right-radius: 0px;
                                 border-bottom-left-radius: 10px;
                                 border-bottom-right-radius: 10px;
                              """
      movieNameStyleSheet =   """
                                 color: rgba(3, 4, 32, 1);
                              """ 
      authorNameStyleSheet =  """
                                 color: rgba(5, 6, 32, 0.5);
                              """
#__________________________________________________________________________________________________________

      self.id = movie_id
      
      self.font = QtGui.QFont()
      self.font.setFamily("Inter")

      self.layout = QtWidgets.QVBoxLayout()
      self.setLayout(self.layout)

      self.plate_widget = QtWidgets.QWidget()
      self.plate_widget.setFixedSize(165, 250)
      self.plate_widget.setStyleSheet(plateStyleSheet)
      self.plate_widget.setObjectName("plate_widget")

      self.plateName_frame = QtWidgets.QFrame(self.plate_widget)
      self.plateName_frame.setGeometry(QtCore.QRect(0, 205, 165, 45))
      self.plateName_frame.setStyleSheet(plateNameStyleSheet)
      self.plateName_frame.setObjectName("plateName_frame")

      self.preview_label = QtWidgets.QLabel(self.plate_widget)
      self.preview_label.setGeometry(0, 0, 165, 205)
      self.preview_label.setPixmap(QtGui.QPixmap("UI\images\preview_placeholder.png"))
      self.preview_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)

      self.movieName_label = QtWidgets.QLabel(self.plateName_frame)
      self.movieName_label.setGeometry(QtCore.QRect(5, 5, 155, 20))
      self.font.setPointSize(10)
      self.movieName_label.setFont(self.font)
      self.movieName_label.setStyleSheet(movieNameStyleSheet)
      self.movieName_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
      self.movieName_label.setText("<strong>{}</strong>".format(movieName))

      self.authorName_label = QtWidgets.QLabel(self.plateName_frame)
      self.authorName_label.setGeometry(QtCore.QRect(5, 25, 155, 15))
      self.font.setPointSize(7)
      self.authorName_label.setFont(self.font)
      self.authorName_label.setStyleSheet(authorNameStyleSheet)
      self.authorName_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
      self.authorName_label.setText("<strong>{}</strong>".format(authorName))

      self.layout.addWidget(self.plate_widget)

      self.plate_widget.mouseReleaseEvent = lambda event: self.PlateClicked()

   def PlateClicked(self):
        self.plateClicked_signal.emit(self.id)
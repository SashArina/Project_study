from PyQt6 import QtCore, QtGui, QtWidgets


class PlateDiscription(QtWidgets.QWidget):
   visible = False


   def __init__(self, parent = None):
      super().__init__(parent)

#_____________________________________________StyleSheets__________________________________________________
      discriptionFrameStyleSheet =          """
            background-color: rgba(255, 95, 0, 1);
            border-radius: 10px;
         """     
      discriptionLabelStyleSheet =     """
                                          padding-left: 5px;
                                          padding-top: 1px;
                                          color: rgba(255, 95, 0, 0.5);
                                          background-color: rgba(255, 95, 0, 0.1);
                                       """
      discriptionTextAreaStyleSheet =  """
                                          padding: 5px;
                                          color: rgba(5, 6, 32, 0.5);
                                          background-color: rgba(255, 255, 255, 0.1);
                                       """
      closeButtonStyleSheet =          """
                                          QPushButton {\n
                                             border-top-left-radius: 5px;
                                             border-top-right-radius: 10px;
                                             border-bottom-left-radius: 10px;
                                             border-bottom-right-radius: 5px;
                                             color: rgba(153, 50, 204, 1);
                                             background-color: rgba(30, 30, 30, 1);
                                          }
                                          QPushButton:hover:hover{
                                             background-color: rgba(111, 14, 14, 1);
                                          }
                                       """
      previewFrameStyleSheet =         """
                                          background-color: rgba(217, 217, 217, 1);
                                          border-radius: 10px;
                                       """
      previewLabelStyleSheet =         """
                                          background-color: rgba(0, 0, 0, 0);
                                       """
      mainNameLabelStyleSheet =        """
                                          color: rgba(3, 4, 32, 1);
                                       """    
      subNameLabelStyleSheet =         """
                                          color: rgba(5, 6, 32, 0.5);
                                       """
      scoreFrameStyleSheet =           """
                                          background-color: rgba(255, 255, 255, 0.1)
                                       """
      self.scorePointStyleSheet =      """
                                          background-color: rgba(219, 176, 25, 1);
                                       """
#__________________________________________________________________________________________________________

      self.font = QtGui.QFont()
      self.font.setFamily("Inter")

      self.discription_frame = QtWidgets.QFrame(parent)
      self.discription_frame.setGeometry(QtCore.QRect(50, 50, 900, 580))
      self.discription_frame.setStyleSheet(discriptionFrameStyleSheet)
      self.discription_frame.setObjectName("discription_frame")
      self.discription_frame.setVisible(self.visible)

      shadow = QtWidgets.QGraphicsDropShadowEffect(
            self,
            blurRadius=100.0,
            color=QtGui.QColor(0, 0, 0),
            offset=QtCore.QPointF(0.0, 0.0),
        )
      self.discription_frame.setGraphicsEffect(shadow)

      self.close_button = QtWidgets.QPushButton(self.discription_frame)
      self.close_button.setGeometry(QtCore.QRect(870, 0, 30, 30))
      self.close_button.setFont(self.font)
      self.close_button.setText("X")
      self.close_button.setStyleSheet(closeButtonStyleSheet)
      self.close_button.setObjectName("close_button")
      self.close_button.clicked.connect(self.SetVisible)

      self.preview_frame = QtWidgets.QFrame(self.discription_frame)
      self.preview_frame.setGeometry(QtCore.QRect(40, 40, 264, 328))
      self.preview_frame.setStyleSheet(previewFrameStyleSheet)

      self.preview_label = QtWidgets.QLabel(self.preview_frame)
      self.preview_label.setGeometry(0, 0, 264, 328)
      self.preview_label.setStyleSheet(previewLabelStyleSheet)
      self.preview_label.setPixmap(QtGui.QPixmap("UI\images\preview_placeholder.png"))
      self.preview_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)

      self.movieName_label = QtWidgets.QLabel(self.discription_frame)
      self.movieName_label.setGeometry(QtCore.QRect(40, 408, 264, 30))
      self.font.setPointSize(20)
      self.movieName_label.setFont(self.font)
      self.movieName_label.setStyleSheet(mainNameLabelStyleSheet)
      self.movieName_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
      self.movieName_label.setWordWrap(True)

      self.studioName_label = QtWidgets.QLabel(self.discription_frame)
      self.studioName_label.setGeometry(QtCore.QRect(40, 478, 264, 22))
      self.font.setPointSize(15)
      self.studioName_label.setFont(self.font)
      self.studioName_label.setStyleSheet(subNameLabelStyleSheet)
      self.studioName_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)

      self.authorName_label = QtWidgets.QLabel(self.discription_frame)
      self.authorName_label.setGeometry(QtCore.QRect(40, 510, 264, 22))
      self.font.setPointSize(15)
      self.authorName_label.setFont(self.font)
      self.authorName_label.setStyleSheet(subNameLabelStyleSheet)
      self.authorName_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)

      self.genre_label = QtWidgets.QLabel(self.discription_frame)
      self.genre_label.setGeometry(QtCore.QRect(324, 60, 536, 20))
      self.font.setPointSize(10)
      self.genre_label.setFont(self.font)
      self.genre_label.setStyleSheet(discriptionLabelStyleSheet)
      self.genre_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)

      self.duration_label = QtWidgets.QLabel(self.discription_frame)
      self.duration_label.setGeometry(QtCore.QRect(324, 90, 536, 20))
      self.font.setPointSize(10)
      self.duration_label.setFont(self.font)
      self.duration_label.setStyleSheet(discriptionLabelStyleSheet)
      self.duration_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)

      self.releaseYear_label = QtWidgets.QLabel(self.discription_frame)
      self.releaseYear_label.setGeometry(QtCore.QRect(324, 120, 536, 20))
      self.font.setPointSize(10)
      self.releaseYear_label.setFont(self.font)
      self.releaseYear_label.setStyleSheet(discriptionLabelStyleSheet)
      self.releaseYear_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)

      self.review_label = QtWidgets.QLabel(self.discription_frame)
      self.review_label.setGeometry(QtCore.QRect(324, 150, 536, 218))
      self.font.setPointSize(10)
      self.review_label.setFont(self.font)
      self.review_label.setStyleSheet(discriptionTextAreaStyleSheet)
      self.review_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
      self.review_label.setWordWrap(True)

      self.actors_label = QtWidgets.QLabel(self.discription_frame)
      self.actors_label.setGeometry(QtCore.QRect(324, 378, 536, 100))
      self.font.setPointSize(10)
      self.actors_label.setFont(self.font)
      self.actors_label.setStyleSheet(discriptionTextAreaStyleSheet)
      self.actors_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
      self.actors_label.setWordWrap(True)

      self.score_layout = QtWidgets.QHBoxLayout()

      self.score_frame = QtWidgets.QFrame(self.discription_frame)
      self.score_frame.setGeometry(560, 500, 300, 43)
      self.score_frame.setLayout(self.score_layout)
      self.score_frame.setStyleSheet(scoreFrameStyleSheet)

      for i in range (10):
         self.score_layout.addWidget(QtWidgets.QLabel())


   def SetVisible(self):
      self.visible = not (self.visible)
      self.discription_frame.setVisible(self.visible)

   
   def SetData(self, moviedData: list, actorsData: list):
      self.movieName_label.setText("<strong>{}</strong>".format(moviedData[1]))
      self.studioName_label.setText("<strong>{}</strong>".format(moviedData[2]))
      self.authorName_label.setText("<strong>{}</strong>".format(moviedData[6]))
      self.genre_label.setText("Genre: {}".format(moviedData[3]))
      self.duration_label.setText("Duration: {} min".format(moviedData[5]))
      self.releaseYear_label.setText("Year of release: {}".format(moviedData[4]))
      self.review_label.setText("{}".format(moviedData[7]))

      self.actors_label.setText("Actors: ")

      actorsList = []
      for actor in actorsData:
         actorsList.append("".join(actor))

      self.actors_label.setText("Actors: " + ", ".join(actorsList))

      for i in range(10):
         if i < moviedData[8]:
            self.score_layout.itemAt(i).widget().setStyleSheet(self.scorePointStyleSheet)
from PyQt6 import QtCore, QtGui, QtWidgets
from datetime import datetime
import json


class Filter(QtWidgets.QWidget):
   visible = False
   filter_signal = QtCore.pyqtSignal(list)

   def __init__(self, parent = None):
      super().__init__(parent)

#_____________________________________________StyleSheets__________________________________________________
      filterStyleSheet =   """
                              background-color: rgba(116, 124, 166, 1);
                              border-top-left-radius: 0px;
                              border-top-right-radius: 0px;
                              border-bottom-left-radius: 10px;
                              border-bottom-right-radius: 10px;
                           """  
      comboBoxStyleSheet = """
                              background-color: rgba(217, 217, 217, 1);
                              color: rgba(152, 255, 152, 1);
                              border-radius: 5px;
                           """ 
      spinBoxStyleSheet =  """
                              background-color: rgba(217, 217, 217, 1);
                              color: rgba(3, 4, 32, 1);
                              border-radius: 5px;
                           """     
      buttonStyleSheet =   """
                              QPushButton {
                                 background-color: rgba(217, 217, 217, 1);
                                 color: rgba(3, 4, 32, 1);
                                 border-radius: 5px;
                              }
                              QPushButton:hover:hover{
                                 background-color: rgba(200, 200, 200, 1);
                              }
                           """ 
#__________________________________________________________________________________________________________

      self.font = QtGui.QFont()
      self.font.setFamily("Inter")

      self.filter_widget = QtWidgets.QFrame(parent)
      self.filter_widget.setGeometry(QtCore.QRect(755, 80, 190, 190))
      self.filter_widget.setStyleSheet(filterStyleSheet)
      self.filter_widget.setObjectName("filter_widget")
      self.filter_widget.setVisible(self.visible)

      shadow = QtWidgets.QGraphicsDropShadowEffect(
            self,
            blurRadius=100.0,
            color=QtGui.QColor(0, 0, 0),
            offset=QtCore.QPointF(0.0, 0.0),
        )
      self.filter_widget.setGraphicsEffect(shadow)

      self.genre_comboBox = QtWidgets.QComboBox(self.filter_widget)
      self.genre_comboBox.setGeometry(QtCore.QRect(15, 15, 160, 20))
      self.genre_comboBox.setStyleSheet(comboBoxStyleSheet)
      self.genre_comboBox.addItem("Any")
      self.genre_comboBox.addItems(json.load(open("UI\jsons\genre.json")))

      self.studio_comboBox = QtWidgets.QComboBox(self.filter_widget)
      self.studio_comboBox.setGeometry(QtCore.QRect(15, 50, 160, 20))
      self.studio_comboBox.setStyleSheet(comboBoxStyleSheet)
      self.studio_comboBox.addItem("Any")
      self.studio_comboBox.addItems(json.load(open("UI\jsons\studios.json")))

      self.durationMin_spinBox = QtWidgets.QSpinBox(self.filter_widget)
      self.durationMin_spinBox.setGeometry(QtCore.QRect(15, 85, 75, 20))
      self.durationMin_spinBox.setStyleSheet(spinBoxStyleSheet)
      self.durationMin_spinBox.setMinimum(1)
      self.durationMin_spinBox.setMaximum(99999998)
      self.durationMin_spinBox.setValue(1)
      self.durationMin_spinBox.valueChanged.connect(self.MinDurationChanged)

      self.durationMax_spinBox = QtWidgets.QSpinBox(self.filter_widget)
      self.durationMax_spinBox.setGeometry(QtCore.QRect(100, 85, 75, 20))
      self.durationMax_spinBox.setStyleSheet(spinBoxStyleSheet)
      self.durationMax_spinBox.setMinimum(2)
      self.durationMax_spinBox.setMaximum(99999999)
      self.durationMax_spinBox.setValue(99999999)
      self.durationMax_spinBox.valueChanged.connect(self.MaxDurationChanged)

      self.releasePeriodStart_spinBox = QtWidgets.QSpinBox(self.filter_widget)
      self.releasePeriodStart_spinBox.setGeometry(QtCore.QRect(15, 120, 75, 20))
      self.releasePeriodStart_spinBox.setStyleSheet(spinBoxStyleSheet)
      self.releasePeriodStart_spinBox.setMinimum(1900)
      self.releasePeriodStart_spinBox.setMaximum(datetime.now().year-1)
      self.releasePeriodStart_spinBox.setValue(1900)
      self.releasePeriodStart_spinBox.valueChanged.connect(self.ReleasePeriodStartChanged)

      self.releasePeriodEnd_spinBox = QtWidgets.QSpinBox(self.filter_widget)
      self.releasePeriodEnd_spinBox.setGeometry(QtCore.QRect(100, 120, 75, 20))
      self.releasePeriodEnd_spinBox.setStyleSheet(spinBoxStyleSheet)
      self.releasePeriodEnd_spinBox.setMinimum(1901)
      self.releasePeriodEnd_spinBox.setMaximum(datetime.now().year)
      self.releasePeriodEnd_spinBox.setValue(datetime.now().year)
      self.releasePeriodEnd_spinBox.valueChanged.connect(self.ReleasePeriodEndChanged)

      self.apply_button = QtWidgets.QPushButton(self.filter_widget)
      self.apply_button.setGeometry(QtCore.QRect(15, 155, 75, 20))
      self.apply_button.setText("Apply")
      self.apply_button.setStyleSheet(buttonStyleSheet)
      self.apply_button.clicked.connect(self.ApplyFilter)

      self.reset_button = QtWidgets.QPushButton(self.filter_widget)
      self.reset_button.setGeometry(QtCore.QRect(100, 155, 75, 20))
      self.reset_button.setText("Reset")
      self.reset_button.setStyleSheet(buttonStyleSheet)
      self.reset_button.clicked.connect(self.ResetFilter)


   def MinDurationChanged(self):
      if(self.durationMin_spinBox.value() == self.durationMax_spinBox.value() & self.durationMax_spinBox.value() < 99999999):
         self.durationMax_spinBox.setValue(self.durationMin_spinBox.value() + 1)

   
   def MaxDurationChanged(self):
      if(self.durationMin_spinBox.value() == self.durationMax_spinBox.value() & self.durationMin_spinBox.value() > 1):
         self.durationMin_spinBox.setValue(self.durationMax_spinBox.value() - 1)


   def ReleasePeriodStartChanged(self):
      if(self.releasePeriodStart_spinBox.value() == self.releasePeriodEnd_spinBox.value() & self.releasePeriodEnd_spinBox.value() < 99999999):
         self.releasePeriodEnd_spinBox.setValue(self.releasePeriodStart_spinBox.value() + 1)


   def ReleasePeriodEndChanged(self):
      if(self.releasePeriodEnd_spinBox.value() == self.releasePeriodStart_spinBox.value() & self.releasePeriodStart_spinBox.value() > 1):
         self.releasePeriodStart_spinBox.setValue(self.releasePeriodEnd_spinBox.value() - 1)


   def SetVisible(self):
      self.visible = not (self.visible)
      self.filter_widget.setVisible(self.visible)


   def ApplyFilter(self):
      self.visible = not (self.visible)
      self.filter_widget.setVisible(self.visible)

      self.filter_signal.emit([self.genre_comboBox.currentText(), self.studio_comboBox.currentText(), self.durationMin_spinBox.value(), self.durationMax_spinBox.value(), self.releasePeriodStart_spinBox.value(), self.releasePeriodEnd_spinBox.value()])


   def ResetFilter(self):
      self.genre_comboBox.setCurrentIndex(0)
      self.studio_comboBox.setCurrentIndex(0)
      self.durationMin_spinBox.setValue(1)
      self.durationMax_spinBox.setValue(99999999)
      self.releasePeriodStart_spinBox.setValue(1900)
      self.releasePeriodEnd_spinBox.setValue(datetime.now().year)

      self.ApplyFilter()
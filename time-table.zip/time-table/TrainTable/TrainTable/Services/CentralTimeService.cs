﻿using System;
using System.Windows;
using System.Windows.Threading;

namespace TrainTable;

public class CentralTimeService
{
    private readonly DispatcherTimer _timer = new();
    private int _second;

    public event Action<TimeServiceContext>? SecondPassed;

    public static DateTimeOffset CurrentLocalTime => DateTimeOffset.UtcNow.ToLocalTime();

    public CentralTimeService()
    {
        _timer.Interval = TimeSpan.FromSeconds(1);

        _timer.Tick += (object? sender, EventArgs args) =>
        {
            SecondPassed?.Invoke(new TimeServiceContext(_second++));     
        };
    }

    public void Start() => _timer.Start();

    public void Stop() => _timer.Stop();

    public void DoWithInterval(Action<TimeServiceContext> action, int intervalInSeconds)
    {
        SecondPassed += context => 
        { 
            if (context.Second % intervalInSeconds == 0)
            {
                action?.Invoke(context);
            }
        };
    }
}

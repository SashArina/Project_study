﻿namespace TrainTable.Services;

public class ControlService
{
    public ControlService(CentralTimeService centralTimeService)
    {
        CentralTimeService = centralTimeService;
    }

    public CentralTimeService CentralTimeService { get; private set; }
}

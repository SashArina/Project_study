﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TrainTable.Data;
using TrainTable.Entities;

namespace TrainTable.Services;

public class SubwayBoardController
{
    private const int MaxMessagesCount = 10;

    private readonly ControlService _controlService;
    private readonly AppDataBase _dataBase;

    public SubwayBoardController(ControlService controlService, AppDataBase dataBase)
    {
        _controlService = controlService;
        _dataBase = dataBase;
    }

    public CentralTimeService CentralTimeService { get => _controlService.CentralTimeService; }

    public IEnumerable<AdvertisingMessage> GetMessages()
    {
        return _dataBase.Messages.ToList();
    }

    public int GetMessagesCount()
    {
        return _dataBase.Messages.Count();
    }

    public AdvertisingMessage? GetMessage(int id)
    {
        return _dataBase.Messages.FirstOrDefault(x => x.Id == id);
    }

    public bool IsMessagesMax()
    {
        return GetMessagesCount() >= MaxMessagesCount;
    }

    public bool RemoveMessage(int id)
    {
        var message = GetMessage(id);

        if(message == null)
        {
            return false;
        }

        _dataBase.Messages.Remove(message);
        _dataBase.SaveChanges();

        return true;
    }

    public void AddMessage(string message)
    {
        if(IsMessagesMax())
        {
            RemoveFirstMessage();
        }

        AddMessageAtTheEnd(message);
    }

    public void EditMessage(int id, string message)
    {
        var advMessage = GetMessage(id);

        if(advMessage == null)
        {
            return;
        }

        advMessage.Text = message;

        _dataBase.Messages.Update(advMessage);
        _dataBase.SaveChanges();
    }

    private void RemoveFirstMessage()
    {
        var firstMessage = _dataBase.Messages.OrderBy(x => x.Id).FirstOrDefault();

        if(firstMessage == null)
        {
            return;
        }

        _dataBase.Messages.Remove(firstMessage);
        _dataBase.SaveChanges();
    }

    private void AddMessageAtTheEnd(string message)
    {
        var advMessage = new AdvertisingMessage { Text = message };

        _dataBase.Messages.Add(advMessage);
        _dataBase.SaveChanges();
    }

    public IEnumerable<SheduleUnit> GetShedule(DateTimeOffset date)
    {
        return _dataBase.Shedule
            .Where(x => x.ExpectedDepartureTime.Day == date.Day)
            .OrderBy(x => x.ExpectedDepartureTime)
            .ToList();
    }

    public void SetDepartureTime(int id, DateTimeOffset time)
    {
        var unit = _dataBase.Shedule
            .FirstOrDefault(x => x.Id == id);

        if(unit == null)
        {
            return;
        }

        unit.RealDepartureTime = time.ToUniversalTime();
        _dataBase.Shedule.Update(unit);
        _dataBase.SaveChanges();
    }
}

﻿using System;

namespace TrainTable;

public class TimeServiceContext
{
    public TimeServiceContext(int second)
    {
        var currentDateTime = DateTime.Now;

        CurrentDate = new DateOnly(currentDateTime.Year, currentDateTime.Month, currentDateTime.Day);
        CurrentTime = new TimeOnly(currentDateTime.Hour, currentDateTime.Minute, currentDateTime.Second);
        Second = second;
    }

    public DateOnly CurrentDate { get; private set; }
    public TimeOnly CurrentTime { get; private set; }
    public int Second { get; private set; }
}

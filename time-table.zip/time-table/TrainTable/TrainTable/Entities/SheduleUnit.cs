﻿using System;

namespace TrainTable.Entities
{
    public class SheduleUnit
    {
        public int Id { get; set; }
        public string TrainCode { get; set; } = string.Empty;
        public DateTimeOffset ExpectedDepartureTime { get; set; }
        public DateTimeOffset? RealDepartureTime { get; set; }
        public string Destination { get; set; } = string.Empty;

        public string ExpectedTimeString {  get => ExpectedDepartureTime.ToLocalTime().ToString("HH:mm:ss");}
        public string RealTimeString { get => RealDepartureTime?.ToLocalTime().ToString("HH:mm:ss") ?? "Не прибыл"; }
    }
}

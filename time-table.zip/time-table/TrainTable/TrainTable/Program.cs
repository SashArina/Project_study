﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Linq;
using TrainTable.Data;
using TrainTable.Services;
using TrainTable.ViewModels;
using TrainTable.Views;

namespace TrainTable;

class Program
{
    [STAThread]
    public static void Main()
    {
        var connectionString = "Server=127.0.0.1;Port=3306;Database=metro_db;Uid=root;Pwd=3306;";

        var host = Host.CreateDefaultBuilder()
            .ConfigureServices(services =>
            {
                services.AddSingleton<App>();

                services.AddDbContext<AppDataBase>(options => 
                {
                    options.UseMySql(connectionString, new MySqlServerVersion(new Version(8, 0, 35)));
                }, ServiceLifetime.Singleton);

                services.AddSingleton<CentralTimeService>();
                services.AddSingleton<ControlService>();

                services.AddSingleton<SubwayBoardController>();
                services.AddSingleton<SubwayBoardVm>();
                services.AddSingleton<SubwayBoardView>();

             }).Build();

        
        host.Services.GetRequiredService<CentralTimeService>().Start();

        var dataBase = host.Services.GetRequiredService<AppDataBase>();

        SeedDataBase(dataBase);

        var app = host.Services.GetRequiredService<App>();

        app.Run();
    }

    private static void SeedDataBase(AppDataBase dataBase)
    {
        //dataBase.Database.EnsureDeleted();
        if(!dataBase.Database.EnsureCreated())
            return;

        dataBase.Messages.Add(new Entities.AdvertisingMessage { Text = "Покупайте квартиры класса Комфорт от 30 млн. руб. Подробности на сайте buy.apartment.com" });
        dataBase.Messages.Add(new Entities.AdvertisingMessage { Text = "Самое крупное цирковое представление 2023 года в Санкт-Петербурге" });
        dataBase.Messages.Add(new Entities.AdvertisingMessage { Text = "Медицинский центр \"Галактика\" - запись по телефону +7 949-333-43-54" });
        dataBase.Messages.Add(new Entities.AdvertisingMessage { Text = "Благотворительны фонд \"Спасём мир\" - отправьте сообщение с суммой пожертвования на номер +7-952-234-22-32" });
        dataBase.SaveChanges();

        string[] dests =
        {
            "Проспект Ветеранов",
            "Автово"
        };

        string[] trains =
        {
            "10348",
            "12344",
            "12354",
            "12365",
            "12377",
        };

        int i = 0;
        for(int day = 0; day < 15; ++day)
        {
            for(int trip = 0; trip < 64; ++trip)
            {
                dataBase.Shedule.Add(
                    new Entities.SheduleUnit
                    {
                        TrainCode = trains.ElementAt(i++ % trains.Length),
                        Destination = dests.ElementAt(Random.Shared.Next(dests.Length)),
                        ExpectedDepartureTime = new DateTime(2023, 11, 15, 8, 0, 0).ToUniversalTime()
                            .AddDays(day).AddMinutes(trip*15),
                        RealDepartureTime = null
                    });
            }
        }
        dataBase.SaveChanges();
    }
}

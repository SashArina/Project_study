﻿using Google.Protobuf;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using TrainTable.Base;
using TrainTable.Entities;
using TrainTable.Services;
using TrainTable.Views;

namespace TrainTable.ViewModels;

public class SubwayBoardVm : ViewModelBase
{
    private int _selectedIndex = -1;
    
    public int SelectedIndex 
    { 
        get => _selectedIndex;
        set => Set(ref _selectedIndex, value); 
    }

    public string SelectedItemString => SelectedItem is null ? "Запись не выбрана!" : $"Выбрана запись № {SelectedItem.Id}";

    private SheduleUnit? _selectedItem;

    public SheduleUnit? SelectedItem { get => _selectedItem; set { Set(ref _selectedItem, value); OnPropertyChanged(nameof(SelectedItemString)); } }

    private readonly SubwayBoardController _boardConteroller;

    public ObservableCollection<SheduleUnit> Shedule { get; set; } = new ObservableCollection<SheduleUnit>();

    public SubwayBoardVm(SubwayBoardController subwayBoardController)
    {
        _boardConteroller = subwayBoardController;

        CurrentTime = "00:00:00";
        LastDepartureTime = "00:00";
        CurrentMessage = "Загрузка...";

        ConfigureTimeTriggeredActions();

        SetDepartureCommand = new ActionCommand(arg => 
        {
            int timeout = 10;

            if(arg is SheduleUnit unit)
            {
                if(unit.RealDepartureTime != null)
                {
                    MessageBox.Show($"Поезд уже прибыл", "Сообщение");
                    return;
                }

                if(FromDeparture < timeout)
                {
                    MessageBox.Show($"Время с последнего прибытия поезда слишком мало. Подождите ещё {timeout - FromDeparture} секунд.", "Сообщение");
                    return;
                }

                _fromDeparture = 1;
                _boardConteroller.SetDepartureTime(unit.Id, CentralTimeService.CurrentLocalTime);
                UpdateShedule();
                MessageBox.Show($"Датчик зафиксировал прибытие поезда", "Сообщение");
                SelectedIndex = Shedule.IndexOf(unit) + 1;
            }
            else
            {
                MessageBox.Show($"Поезд для моделирования прибытия не выбран! Выберите не прибывший поезд", "Сообщение");
                return;
            }
               
        });

        EditMessagesCommand = new ActionCommand(arg =>
        {
            MessagesView messages = new MessagesView()
            {
                DataContext = new MessagesVm(_boardConteroller)
            };

            messages.ShowDialog();
        });

        SelectUnitCommand = new ActionCommand(arg =>
        {
            var unit = Shedule
                .FirstOrDefault(x => SecondsOfDay(x.ExpectedDepartureTime.ToLocalTime()) >
                    SecondsOfDay(CentralTimeService.CurrentLocalTime) &&
                    x.RealDepartureTime == null);

            if(unit == null)
            {
                MessageBox.Show("Нечего выбрать!", "Сообщение");
                return;
            }
            else
            {
                SelectedIndex = Shedule.IndexOf(unit);
                SelectedItem = unit;
                MessageBox.Show($"Выбран пункт рассписания № {unit.Id}.", "Сообщение");
            }          
        });
    }

    public int FromDeparture { get => _fromDeparture; set => Set(ref _fromDeparture, value); }

    private int _fromDeparture = 1;

    private string _currentTime = string.Empty;
    public string CurrentTime { get => _currentTime; set => Set(ref _currentTime, value); }

    private string _lastDepartureTime = string.Empty;
    public string LastDepartureTime { get => _lastDepartureTime; set => Set(ref _lastDepartureTime, value); }

    private int _currentMessageIndex = 0;
    private string _currentMessage = string.Empty;
    public string CurrentMessage { get => _currentMessage.ToUpper(); set => Set(ref _currentMessage, value); }

    private DateTime _selectedDate = DateTime.UtcNow;
    public DateTime SelectedDate 
    { 
        get => _selectedDate;
        set
        {
            Set(ref _selectedDate, value);
            UpdateShedule();
        }
    }

    public ICommand SetDepartureCommand { get; set; }
    public ICommand EditMessagesCommand { get; set; }
    public ICommand SelectUnitCommand { get; set; }

    private void ConfigureTimeTriggeredActions()
    {
        _boardConteroller.CentralTimeService
            .DoWithInterval(UpdateCurrentTime, intervalInSeconds: 1);

        _boardConteroller.CentralTimeService
            .DoWithInterval(ShowNextMessage, intervalInSeconds: 5);
    }

    private void UpdateCurrentTime(TimeServiceContext context)
    {
        CurrentTime = context.CurrentTime.ToString("HH:mm:ss");

        LastDepartureTime = new DateTime(1, 1, 1, _fromDeparture / (60*60), _fromDeparture / 60, _fromDeparture % 60)
            .ToString("mm:ss");
        _fromDeparture += 1;
    }

    private void ShowNextMessage(TimeServiceContext context)
    {
        var count = _boardConteroller.GetMessagesCount();

        if(_currentMessageIndex >= count)
        {
            _currentMessageIndex = 0;
        }

        if(count == 0)
        {
            CurrentMessage = "Загрузка...";
            return;
        }

        CurrentMessage = _boardConteroller.GetMessages()
            .ElementAt(_currentMessageIndex++).Text;
    }
    
    private void UpdateShedule()
    {
        var shedule  = _boardConteroller.GetShedule(new DateTimeOffset(SelectedDate.ToUniversalTime()));
    
        Shedule.Clear();
    
        foreach(SheduleUnit unit in shedule)
        {
            Shedule.Add(unit);
        }
    }

    private static int SecondsOfDay(DateTimeOffset date)
    {
        return date.Hour * 60 * 60 +
               date.Minute * 60 +
               date.Second;
    }
}

﻿using System.Collections.ObjectModel;
using System.Text;
using System.Windows;
using System.Windows.Input;
using TrainTable.Base;
using TrainTable.Entities;
using TrainTable.Services;

namespace TrainTable.ViewModels
{
    public class MessagesVm : ViewModelBase
    {
        private const int MaxMessageLength = 106;

        private bool _isMessageDgEdited;
        public bool IsMessageDgEdited { get => _isMessageDgEdited; set => Set(ref _isMessageDgEdited, value); }

        public ObservableCollection<AdvertisingMessage> Messages { get; private set; }
            = new ObservableCollection<AdvertisingMessage>();

        public string Message { get => _message; set { Set(ref _message, value); OnPropertyChanged(nameof(MessageLength)); } }
        private string _message = string.Empty;

        public int MessageLength { get => _message.Length; }
        public bool IsOverflowLength { get => _message.Length > MaxMessageLength; }

        private readonly SubwayBoardController _boardController;

        public MessagesVm(SubwayBoardController subwayBoardController)
        {
            _boardController = subwayBoardController;

            UpdateMessages();

            AddMessageCommand = new ActionCommand((object arg) => 
            {
                if(Message.Length >= MaxMessageLength)
                {
                    MessageBox.Show($"Превышен лимит длины сообщения: {MaxMessageLength - 1} знаков!");
                    return;
                }

                if(_boardController.IsMessagesMax())
                {
                    var result = MessageBox.Show("Вы уверены, что хотите добавить сообщение? Первое сообщение в списке будет перезаписано!", 
                        "Подтверждение", MessageBoxButton.YesNo);

                    if(result != MessageBoxResult.Yes)
                    {
                        return;
                    }
                }

                _boardController.AddMessage(Message);

                MessageBox.Show("Сообщение сохранено!", "Информация");
                Message = "";

                UpdateMessages();

            }, arg => !string.IsNullOrWhiteSpace(Message));

            DeleteMessageCommand = new ActionCommand((object arg) =>
            {
                if(arg is AdvertisingMessage message)
                {
                    var result = MessageBox.Show("Вы уверены, что хотите удалить сообщение?",
                       "Подтверждение", MessageBoxButton.YesNo);

                    if(result != MessageBoxResult.Yes)
                    {
                        MessageBox.Show("Операция отменена!", "Информация");
                        return;
                    }

                    _boardController.RemoveMessage(message.Id);
                    UpdateMessages();
                }
            }, arg => arg != null);

            EditMessagesCommand = new ActionCommand((object arg) =>
            {
                bool haveError = false;
                StringBuilder sb = new();

                sb.AppendLine("Следующие сообщение некорректны: ");

                foreach (var message in Messages)
                {
                    if(message.Text.Length >= MaxMessageLength)
                    {
                        haveError = true;
                        sb.AppendLine($"Сообщение № {message.Id} : {message.Text.Length} символов из {MaxMessageLength - 1};");
                    }
                    else if(string.IsNullOrWhiteSpace(message.Text))
                    {
                        haveError = true;
                        sb.AppendLine($"Сообщение № {message.Id} : пустое сообщение;");
                    }                 
                }

                if(haveError)
                {
                    MessageBox.Show(sb.ToString(), "Ошибка");
                }
                else
                {
                    foreach(var message in Messages)
                    {
                        _boardController.EditMessage(message.Id, message.Text);
                    }

                    MessageBox.Show("Изменения сохранены!", "Информация");
                    UpdateMessages();
                }           
            }, arg => IsMessageDgEdited);
        }

        private void UpdateMessages()
        {
            var messages = _boardController.GetMessages();

            Messages.Clear();

            foreach (AdvertisingMessage message in messages)
            {
                Messages.Add(message);
            }
        }

        public ICommand AddMessageCommand { get; set; }
        public ICommand DeleteMessageCommand { get; set; }
        public ICommand EditMessagesCommand { get; set; }
    }
}

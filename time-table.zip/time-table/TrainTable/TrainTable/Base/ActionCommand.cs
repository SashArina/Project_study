﻿using System;

namespace TrainTable.Base
{
    public class ActionCommand : CommandBase
    {
        private readonly Action<object> _execute;
        private readonly Predicate<object> _canExecute;

        public ActionCommand(
            Action<object> execute,
            Predicate<object> canExecute = null!)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        public override bool CanExecute(object? parameter) => _canExecute?.Invoke(parameter!) ?? true;

        public override void Execute(object? parameter) => _execute?.Invoke(parameter!);
    }
}

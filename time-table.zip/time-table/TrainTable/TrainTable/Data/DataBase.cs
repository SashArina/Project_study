﻿using Microsoft.EntityFrameworkCore;
using TrainTable.Entities;

namespace TrainTable.Data
{
    public class AppDataBase : DbContext
    {
        public DbSet<AdvertisingMessage> Messages { get; set; }
        public DbSet<SheduleUnit> Shedule { get; set; }

        public AppDataBase()
        {
            
        }

        public AppDataBase(DbContextOptions<AppDataBase> options) : base(options)
        {
            
        }
    }
}

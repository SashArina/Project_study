﻿using System.Windows;
using TrainTable.Views;

namespace TrainTable
{
    public class App : Application
    {
        public App(SubwayBoardView subwayBoardView)
        {
            MainWindow = subwayBoardView;

            Current.ShutdownMode = ShutdownMode.OnExplicitShutdown;
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            MainWindow.Show();

            base.OnStartup(e);
        }
    }
}

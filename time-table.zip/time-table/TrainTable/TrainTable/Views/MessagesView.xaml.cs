﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TrainTable.ViewModels;

namespace TrainTable.Views
{
    /// <summary>
    /// Логика взаимодействия для MessagesView.xaml
    /// </summary>
    public partial class MessagesView : Window
    {
        public MessagesView()
        {
            InitializeComponent();
        }

        private void MessagesDG_BeginningEdit(object sender, DataGridBeginningEditEventArgs e)
        {
            if(DataContext is MessagesVm vm)
            {
                vm.IsMessageDgEdited = true;
            }
        }
    }
}
